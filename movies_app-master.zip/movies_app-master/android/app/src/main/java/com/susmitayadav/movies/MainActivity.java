package com.susmitayadav.movies;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
